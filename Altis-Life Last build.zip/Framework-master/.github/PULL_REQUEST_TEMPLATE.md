Resolves #<issue ID here>. 

#### Changes proposed in this pull request: 
- 
