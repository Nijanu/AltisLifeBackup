<b>Altis Life</b> or <b>[Altis Life RPG] (http://www.altisliferpg.com)</b> is developed by <b>Tonic</b> AKA <b>[TAW_Tonic] (https://github.com/TAWTonic)</b>.<br/>
Altis Life RPG by Tonic is licensed under a [Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License] (http://creativecommons.org/licenses/by-nc-nd/3.0/deed.en_US)<br/>

<p align="center">
    <a href="https://travis-ci.org/AsYetUntitled/Framework">
        <img src="https://api.travis-ci.org/AsYetUntitled/Framework.svg" alt="Build Status">
    </a>
       <a href="https://discord.gg/yfAMTFp">
        <img src="https://img.shields.io/badge/Discord-Join%20chat%20→-738bd7.svg" alt="Join the chat at https://discord.gg/yfAMTFp">
    </a>
         <a href="https://trello.com/b/LO0Tivht">
        <img src="https://img.shields.io/badge/Trello-%E2%86%92-blue.svg" alt="https://trello.com/b/LO0Tivht">
    </a>
</p>
